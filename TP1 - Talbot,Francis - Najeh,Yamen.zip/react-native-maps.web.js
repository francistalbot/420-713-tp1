export default function MapView() {
  return null;
}

export const Marker = () => null;
export const Polyline = () => null;
