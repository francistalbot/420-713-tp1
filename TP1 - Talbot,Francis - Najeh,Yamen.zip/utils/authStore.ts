import { changeUserPassword, createUser, findUserById, updateUserProfile } from "@/models/User";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { findUserByCredentials } from "../models/User";
const isWeb = Platform.OS === "web";

type UserState = {
  userId: number | null;
  logIn: (email: string, password: string) => Promise<void>;
  logOut: () => Promise<void>;
  createUser: (
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ) => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  getUserInfo: () => Promise<any>;
  modifyUserInfo: (firstName: string, lastName: string, email: string) => Promise<void>;
};

export const useAuthStore = create(
  persist<UserState>(
    (set) => ({
      userId: null,
      logIn: async (email: string, password: string) => {
        const result = await findUserByCredentials(email, password);
        if (result) {
          set((state) => ({ ...state, userId: result.id }));
        }
      },

      logOut: async () => {
        set((state) => ({ ...state, userId: null }));
      },
      createUser: async (firstName: string, lastName: string, email: string, password: string) => {
        // Implementation for creating a user goes here
        const result = await createUser(firstName, lastName, email, password);
        if (result.id) {
          set((state) => ({ ...state, userId: result.id }));
        }
      },

      changePassword: async (oldPassword: string, newPassword: string) => {
        const userId = useAuthStore.getState().userId;
        if (!userId) throw new Error("User not logged in");
        await changeUserPassword(userId, oldPassword, newPassword);
      },

      getUserInfo: async () => {
        const userId = useAuthStore.getState().userId;
        if (!userId) throw new Error("User not logged in");

        const user = await findUserById(userId);
        if (!user) throw new Error("User not found");
        return user;
      },
      modifyUserInfo: async (firstName: string, lastName: string, email: string) => {
        const userId = useAuthStore.getState().userId;
        if (!userId) throw new Error("User not logged in");
        await updateUserProfile(userId, firstName, lastName, email);
      
      },
    }),
    {
      name: "auth-store",
      storage: isWeb
        ? createJSONStorage(() => localStorage)
        : createJSONStorage(() => ({
            setItem: (key: string, value: string) =>
              SecureStore.setItemAsync(key, value),
            getItem: (key: string) => SecureStore.getItemAsync(key),
            removeItem: (key: string) => SecureStore.deleteItemAsync(key),
          })),
    }
  )
);
